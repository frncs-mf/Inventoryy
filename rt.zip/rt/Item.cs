﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChapelInventorySystem
{
    public partial class Item : Form
    {
        private OleDbConnection con = Connections.GetConnection();

        public Item()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (OleDbConnection con = new OleDbConnection(Connections.connection))
            {
                con.Open();

                if (string.IsNullOrEmpty(txtID.Text) || string.IsNullOrEmpty(txtQty.Text) || string.IsNullOrEmpty(txtAvail.Text))
                {
                    MessageBox.Show("Please fill all fields!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Check if the item exists
                    OleDbCommand chkItem = new OleDbCommand("SELECT ItemName, Quantity FROM Items WHERE ItemName = @ItemName", con);
                    chkItem.Parameters.AddWithValue("@ItemName", txtItem.Text);

                    using (OleDbDataReader reader = chkItem.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // If item exists, update to add quantity
                            int existingQty = reader.GetInt32(reader.GetOrdinal("Quantity"));
                            int newQty = existingQty + int.Parse(txtQty.Text);

                            OleDbCommand updateCmd = new OleDbCommand("UPDATE Items SET Quantity = @UpdatedQty WHERE ItemName = @ItemName", con);
                            updateCmd.Parameters.AddWithValue("@UpdatedQty", newQty);
                            updateCmd.Parameters.AddWithValue("@ItemName", txtItem.Text);
                            updateCmd.ExecuteNonQuery();

                            MessageBox.Show("Item quantity updated successfully!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            // If item does not exist, add item to db
                            OleDbCommand addCmd = new OleDbCommand("INSERT INTO Items (ItemName,Quantity , Availability) VALUES (@ItemName, @Availability, @Quantity)", con);
                            addCmd.Parameters.AddWithValue("@ItemName", txtItem.Text);
                            addCmd.Parameters.AddWithValue("@Availability", txtAvail.Text);
                            addCmd.Parameters.AddWithValue("@Quantity", txtQty.Text);

                            addCmd.ExecuteNonQuery();

                            MessageBox.Show("Item successfully added!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }

                    // Refresh the data grid
                    //loaddatagrid();
                    Item_Load(sender, e);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (OleDbConnection con = new OleDbConnection(Connections.connection))
            {
                con.Open();

                if (string.IsNullOrEmpty(txtID.Text) || string.IsNullOrEmpty(txtID.Text) || string.IsNullOrEmpty(txtQty.Text) || string.IsNullOrEmpty(txtAvail.Text))
                {
                    MessageBox.Show("Please fill all fields!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    OleDbCommand chkItem = new OleDbCommand("SELECT [ItemID] FROM Items WHERE [ItemID] = @ItemID", con);
                    chkItem.Parameters.AddWithValue("ItemID", txtID.Text);

                    if (chkItem.ExecuteScalar() != null)
                    {
                        OleDbCommand update = new OleDbCommand("UPDATE Items SET ItemName = @ItemName, Quantity = @Quantity, Availability = @Availability WHERE [ItemID] = @ItemID", con);
                        update.Parameters.AddWithValue("ItemID", txtID.Text);
                        update.Parameters.AddWithValue("ItemName", txtItem.Text);
                        update.Parameters.AddWithValue("Quantity", txtQty.Text);
                        update.Parameters.AddWithValue("Availability", txtAvail.Text);
                        update.ExecuteNonQuery();

                        MessageBox.Show("Item Successfully Updated!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //loaddatagrid();
                        Item_Load(sender, e);
                    }
                    else
                    {
                        MessageBox.Show("Item cannot be updated! Item doesn't Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (OleDbConnection con = new OleDbConnection(Connections.connection))
            {
                con.Open();

                if (string.IsNullOrEmpty(txtID.Text))
                {
                    MessageBox.Show("Please input Item ID!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    OleDbCommand chkItem = new OleDbCommand("SELECT [ItemID] FROM Items WHERE [ItemID] = @ItemID", con);
                    chkItem.Parameters.AddWithValue("ItemID", txtID.Text);

                    if (chkItem.ExecuteScalar() != null)
                    {
                        DialogResult response = MessageBox.Show("Are you sure you want to delete this record?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (response == DialogResult.Yes)
                        {
                            OleDbCommand delete = new OleDbCommand("UPDATE Items SET ItemName = 'Deleted', Availability = 'Deleted', Quantity = 0 WHERE [ItemID] = @ItemID", con);
                            delete.Parameters.AddWithValue("ItemID", txtID.Text);
                            delete.ExecuteNonQuery();

                            MessageBox.Show("Item Successfully Deleted!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            //loaddatagrid();
                            Item_Load(sender,e);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Item cannot be deleted! Item doesn't Exist!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtID.Clear();
            txtItem.Clear();
            txtQty.Clear();
            txtAvail.Clear();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();

            OleDbCommand searchCmd = new OleDbCommand("SELECT * FROM Items WHERE ([ItemID] & ' ' & ItemName & ' ' & Availability & ' ' & Quantity) LIKE @searchString", con);
            searchCmd.Parameters.AddWithValue("searchString", "%" + txtSearch.Text + "%");
            searchCmd.ExecuteNonQuery();

            OleDbDataAdapter adap = new OleDbDataAdapter(searchCmd);
            DataTable dt = new DataTable();
            adap.Fill(dt);

            dgvItems.DataSource = dt;

            con.Close();
        }

  

        private void Item_Load(object sender, EventArgs e)
        {

            using (OleDbConnection con = Connections.GetConnection())
            {
                con.Open();

                OleDbCommand items = new OleDbCommand("SELECT * FROM Items", con);

                OleDbDataAdapter adap = new OleDbDataAdapter(items);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                dgvItems.DataSource = dt;
            }
        }
     
    }
}
