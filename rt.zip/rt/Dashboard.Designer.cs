﻿namespace ChapelInventorySystem
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnItems = new System.Windows.Forms.Button();
            this.btnTransaction = new System.Windows.Forms.Button();
            this.lblAdminDashboard = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnItems
            // 
            this.btnItems.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnItems.Font = new System.Drawing.Font("MS Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItems.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnItems.Location = new System.Drawing.Point(21, 92);
            this.btnItems.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnItems.Name = "btnItems";
            this.btnItems.Size = new System.Drawing.Size(201, 111);
            this.btnItems.TabIndex = 0;
            this.btnItems.Text = "Manage Items";
            this.btnItems.UseVisualStyleBackColor = false;
            this.btnItems.Click += new System.EventHandler(this.btnItems_Click);
            // 
            // btnTransaction
            // 
            this.btnTransaction.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.btnTransaction.Font = new System.Drawing.Font("MS Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransaction.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnTransaction.Location = new System.Drawing.Point(243, 92);
            this.btnTransaction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnTransaction.Name = "btnTransaction";
            this.btnTransaction.Size = new System.Drawing.Size(201, 111);
            this.btnTransaction.TabIndex = 0;
            this.btnTransaction.Text = "Manage Transactions";
            this.btnTransaction.UseVisualStyleBackColor = false;
            this.btnTransaction.Click += new System.EventHandler(this.btnTransaction_Click);
            // 
            // lblAdminDashboard
            // 
            this.lblAdminDashboard.AutoSize = true;
            this.lblAdminDashboard.BackColor = System.Drawing.Color.Transparent;
            this.lblAdminDashboard.Font = new System.Drawing.Font("MS Gothic", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdminDashboard.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblAdminDashboard.Location = new System.Drawing.Point(79, 31);
            this.lblAdminDashboard.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAdminDashboard.Name = "lblAdminDashboard";
            this.lblAdminDashboard.Size = new System.Drawing.Size(317, 37);
            this.lblAdminDashboard.TabIndex = 1;
            this.lblAdminDashboard.Text = "Admin Dashboard";
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ChapelInventorySystem.Properties.Resources._35a54687151732be7c27bb127be015e9;
            this.ClientSize = new System.Drawing.Size(466, 225);
            this.Controls.Add(this.lblAdminDashboard);
            this.Controls.Add(this.btnTransaction);
            this.Controls.Add(this.btnItems);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnItems;
        private System.Windows.Forms.Button btnTransaction;
        private System.Windows.Forms.Label lblAdminDashboard;
    }
}