﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChapelInventorySystem
{
    public partial class Transaction : Form
    {
        private OleDbConnection con = Connections.GetConnection();
        public Transaction()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtID.Clear();
            txtItem.Clear();
            txtQty.Clear();

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            string sql = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\MIGUEL\\rt\\Database2.accdb";
            OleDbConnection con = new OleDbConnection(sql);
            con.Open();
            OleDbCommand command = new OleDbCommand("Insert into Items(ItemID,ItemName,Quantity) values (@ItemID,@ItemName,@Quantity)", con);
            command.Parameters.AddWithValue("@itemID", int.Parse(txtID.Text));
            command.Parameters.AddWithValue("@ItemName", txtItem.Text);
            command.Parameters.AddWithValue("@Quantity", int.Parse(txtQty.Text));

            command.ExecuteNonQuery();
            MessageBox.Show("Success");
            con.Close();
        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            con.Open();

            OleDbCommand searchCmd = new OleDbCommand("SELECT * FROM Items WHERE ([ItemID] & ' ' & ItemName & ' ' & Availability & ' ' & Quantity) LIKE @searchString", con);
            searchCmd.Parameters.AddWithValue("searchString", "%" + txtSearch.Text + "%");
            searchCmd.ExecuteNonQuery();

            OleDbDataAdapter adap = new OleDbDataAdapter(searchCmd);
            DataTable dt = new DataTable();
            adap.Fill(dt);

            dgvItems.DataSource = dt;

            con.Close();
        }

        private void btnBorrow_Click(object sender, EventArgs e)
        {
            string sql = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\MIGUEL\\rt\\Database2.accdb";
            OleDbConnection con = new OleDbConnection(sql);
            con.Open();
            OleDbCommand command = new OleDbCommand("Insert into Payments(ID,Item,Fee) values (@ID,@Item,Fee)", con);
            command.Parameters.AddWithValue("@ID",int.Parse(txtID.Text));
            command.Parameters.AddWithValue("@Item", txtItem.Text);
            command.Parameters.AddWithValue("@Fee", int.Parse(txtQty.Text));

            command.ExecuteNonQuery();
            MessageBox.Show("Success");
            con.Close();
            Transaction_Load(sender, e);
        }


        private void Transaction_Load(object sender, EventArgs e)
        {

            using (OleDbConnection con = Connections.GetConnection())
            {
                con.Open();

                OleDbCommand payment = new OleDbCommand("SELECT * FROM Payments", con);

                OleDbDataAdapter adap = new OleDbDataAdapter(payment);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                dgvItems.DataSource = dt;
            }
            SumFee();
            textBox1.Text = "Php " + retrievedValue;

        }
        /*public string retrievedValue = string.Empty;
        public void SumFee() 
        {
            string sql = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\MIGUEL\\rt\\Database2.accdb";
            OleDbConnection con = new OleDbConnection(sql);
            con.Open();
            OleDbCommand command = new OleDbCommand("SELECT SUM(Payments.Fee), Payments.Item FROM Payments AS [SUM] GROUP BY Payments.Item;", con);
            command.Parameters.AddWithValue("@Item", txtItem.Text);
            command.Parameters.AddWithValue("@Fee", int.Parse(txtQty.Text));


           object result = command.ExecuteScalar();
           if (result != null)
           {
               retrievedValue = result.ToString();
           }
            
                command.ExecuteNonQuery();
            MessageBox.Show("Borrowed Success");
            con.Close();
            //Transaction_Load(sender, e);
        }*/

        public string retrievedValue = string.Empty;

        public void SumFee()
        {
            // Connection string for the database
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\\MIGUEL\\rt\\Database2.accdb";

            // SQL query to sum fees grouped by item
            string query = "SELECT SUM(Payments.Fee) FROM Payments";

            // Create a new connection
            using (OleDbConnection con = new OleDbConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    con.Open();

                    // Create a command with the query and connection
                    using (OleDbCommand command = new OleDbCommand(query, con))
                    {
                        // Add parameters to the command
                        command.Parameters.AddWithValue("@Item", txtItem.Text);

                        // Execute the command and retrieve the result
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            // Store the result in the retrievedValue variable
                            retrievedValue = result.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle any errors that occur during the database operation
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    // Ensure the connection is closed
                    if (con.State == System.Data.ConnectionState.Open)
                    {
                        con.Close();
                    }
                }
            }
        }

        private void btnTotal_Click(object sender, EventArgs e)
        {

        }

        private void txtQty_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
